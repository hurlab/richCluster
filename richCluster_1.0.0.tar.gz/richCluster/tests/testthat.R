library(testthat)
library(richCluster)

test_check("richCluster")
