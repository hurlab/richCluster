#' richCluster: clustering and visualization utilities
#'
#' Tools for clustering enriched terms, building correlation networks,
#' and producing interactive heatmaps and network views.
#'
#' @keywords internal
#' @name richCluster-package
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
